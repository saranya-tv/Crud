const express = require("express")
const mongoose = require("mongoose")
const bodyParser = require("body-parser")
const apps = require('./routes/users')
const app = express()
app.use(
    bodyParser.urlencoded({
        extended:false
    })
    )
    app.use(bodyParser.json())
    const db = require("./config/conf").mongoURI
    mongoose.connect(db,{useNewUrlParser:true})
    .then(()=>console.log("MongoDB successfully connected"))
    .catch(err=>console.log(err))
    app.use('/users',apps)
    app.listen(3000, ()=>console.log("server up and running on port 3000"))
