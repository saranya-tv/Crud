const validator = require('validator')
const isEmpty = require('isempty')
module.exports = function validateRegisterInput(data){
    let errors = {}
    data.roll_no = !isEmpty(data.roll_no) ? data.roll_no :""
    data.name = !isEmpty(data.name)? data.name :""
    
    if(validator.isEmpty(data.roll_no)) {
        errors.roll_no = "rollno field is required"
    }
    if(validator.isEmpty(data.name)) {
        errors.name = "Name field is required"
    }
    else if(data.name.length<=4){
        errors.name = "Name should have atleast 4 letters"
    }
    
    
    if(data.marks===undefined||data.marks==="") {
        errors.marks = "marks field is required"
    }
   

    return {
        errors,
        isValid:isEmpty(errors)
    }
}