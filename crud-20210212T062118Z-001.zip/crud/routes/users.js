const express = require('express')
const mongoose = require('mongoose')
const router = express.Router()
const student = require('../models/user')
const regvalidation = require('../validation/valid')
const isEmpty = require('isempty')
mongoose.set('useFindAndModify',false)
router.get('/',(req,res)=>{
    return res.json({message:"Successfully"})
})
router.post('/register',(req,res)=>{
    student.findOne({roll_no:req.body.roll_no}).then(data=>{
        if(!isEmpty(data))
        {
            return res.json("rollno already exist")
        }
    })
   
    const {errors,isValid} =regvalidation(req.body)
    if(!isValid){
        return res.status(400).json(errors)
    }
    else
    {
       

        const regInput = new student({
            roll_no:req.body.roll_no,
            name:req.body.name,
            marks:req.body.marks,
           
           
        
            
        })
        regInput.save().then(data=>{
            res.json(data)
        }).catch(err=>{
            console.log(err)
        })

    }

    }
)


router.get('/show',(req,res)=>{
    student.find().then(data=>{res.json(data)})
    .catch(err=>{console.log(err)})
    })
    router.get('/show/:id',(req,res)=> {
        student.findById(req.params.id).then(data=>{res.json(data)})
        .catch(err=>{console.log(err)})
    })
    router.delete('/delete/:id',(req,res)=>{
        student.findByIdAndDelete(req.params.id).then(data=>{res.json("deleted")})
        .catch(err=>{console.log(err)})
    })
    router.put('/update/:id',(req,res)=>{
        student.findByIdAndUpdate(req.params.id,{$set:req.body},{new:true},(err,data)=>{
     if(err){
    return res.json({status:"failed",message:err.message})
      }
      return res.json({status:"success",data:data})
        }
            
    
           
     )})
module.exports = router