const mongoose = require("mongoose")
const Schema = mongoose.Schema
const UserSchema = new Schema({
    roll_no:{
        type:Number,
        required:true
    },
    name:{
        type:String,
        required:true
    },

      marks:{
            type:Array,
            required:true,
            english:{type:Number},
            maths:{type:Number},
            cs:{type:Number},
            tamil:{type:Number},
            physics:{type:Number}
            

        
        },
   
})
module.exports = User = mongoose.model("users", UserSchema)